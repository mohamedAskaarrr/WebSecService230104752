import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import sqlite3
import hashlib
import os
import shutil
import subprocess
import platform
import time
from datetime import datetime
import re # For parsing SFTP ls output

# --- WARNINGS AND PREREQUISITES ---
WARNING_CLI_SFTP = """
############################################################################
# WARNING: USING COMMAND-LINE SFTP (NO PARAMIKO)                           #
# This version uses the system's 'sftp' command-line client.             #
# 1. SSH KEY-BASED AUTHENTICATION to your SFTP server is STRONGLY RECOMMENDED. #
#    Setup: ssh-keygen, then ssh-copy-id sftpuser@YOUR_SFTP_HOST         #
# 2. 'sftp' CLI must be installed and in PATH.                             #
# 3. For password fallback (LESS SECURE), 'sshpass' must be installed:     #
#    sudo apt install sshpass                                              #
# This method is less robust and more complex than using 'paramiko'.       #
############################################################################
"""
print(WARNING_CLI_SFTP)

# --- SECURITY WARNING ---
SECURITY_WARNING_INSECURE_PASSWORDS = """
############################################################################
# WARNING: INSECURE PASSWORD HANDLING!                                     #
# App user passwords are weakly hashed. File encryption passwords for      #
# shared files are stored IN PLAINTEXT in .keyinfo files on the SFTP server. #
# DO NOT USE THIS FOR REAL SENSITIVE DATA OR IN PRODUCTION.                #
############################################################################
"""
print(SECURITY_WARNING_INSECURE_PASSWORDS)

# --- SQLite Database Configuration (For User Authentication - Stays Local) ---
DB_NAME_AUTH = "secure_share_cli_sftp_auth.db"

# --- SFTP Server Configuration ---
SFTP_HOST = "41.68.139.217"
SFTP_PORT = 22 # Standard SSH/SFTP port
SFTP_USER = "sftpuser"
# SFTP_PASS: Only used if USE_SSHPASS_FALLBACK is True and SSH keys fail/not set.
#            Prompting for this or storing it securely is a challenge.
#            For this example, if USE_SSHPASS_FALLBACK, it will use the one below.
#            IN A REAL APP, DO NOT HARDCODE PASSWORDS.
SFTP_PASS_FOR_FALLBACK = "sftpuser" # <<< EXTREMELY INSECURE - FOR DEMO FALLBACK ONLY
USE_SSHPASS_FALLBACK = True # Set to False to ONLY allow SSH key auth
SSH_KEY_PATH = None # Optional: Path to a specific private key, e.g., "~/.ssh/id_rsa_sftponly"

SFTP_REMOTE_APP_BASE_DIR = "secure_share_remote_storage" # Root for ALL app data on SFTP server
SFTP_MY_FILES_DIR_NAME = "_my_files"
SFTP_SHARED_WITH_ME_DIR_NAME = "_shared_with_me"
SFTP_KEY_SUFFIX = ".keyinfo"

# --- Local Temporary Staging ---
LOCAL_TEMP_DIR_BASE = "client_temp_files_cli_sftp"

# --- Configurable Path for code.sh ---
CODE_SH_SCRIPT_PATH = "./code.sh"
PASSWORD_SALT = b"a_very_static_salt_for_cli_sftp"

# --- Helper: find_bash_on_windows() (Same as before) ---
def find_bash_on_windows():
    common_paths = [
        os.path.join(os.environ.get("ProgramFiles", "C:\\Program Files"), "Git", "usr", "bin", "bash.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)"), "Git", "usr", "bin", "bash.exe"),
        shutil.which("bash")
    ]
    for path in common_paths:
        if path and os.path.exists(path): return path
    return "bash"

# --- Database Setup (SQLite - Users Table ONLY - Stays Local) ---
def init_auth_db():
    conn = sqlite3.connect(DB_NAME_AUTH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )''')
    conn.commit()
    print(f"Authentication Database '{DB_NAME_AUTH}' checked/created.")
    conn.close()

# --- User Authentication Logic ---
def hash_password_insecure(password):
    hasher = hashlib.sha256(); hasher.update(PASSWORD_SALT); hasher.update(password.encode('utf-8')); return hasher.hexdigest()
def check_password_insecure(password, stored_hash): return hash_password_insecure(password) == stored_hash
def login_user(username, password):
    # ... (same as before, local DB check)
    if not username or not password: return False, "Username/password cannot be empty.", None, None
    conn = sqlite3.connect(DB_NAME_AUTH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (username,))
        result = cursor.fetchone()
        if result:
            user_id, fetched_username, stored_hash = result
            if check_password_insecure(password, stored_hash):
                return True, "Login successful!", user_id, fetched_username
            else: return False, "Invalid password.", None, None
        else: return False, "Username not found.", None, None
    except Exception as e: print(f"SQLite Error in login_user: {e}"); return False, f"DB error: {e}", None, None
    finally: conn.close()

# --- run_encryption_script (Same as before) ---
def run_encryption_script(mode, input_file, output_file, password):
    # ... (implementation is identical to your original)
    script_path_abs = os.path.abspath(CODE_SH_SCRIPT_PATH)
    if not os.path.exists(script_path_abs): return False, f"Script not found: {script_path_abs}", ""
    current_os = platform.system()
    if not os.access(script_path_abs, os.X_OK) and current_os != "Windows":
        try: os.chmod(script_path_abs, 0o755)
        except Exception as e: return False, f"Script chmod failed: {e}", ""

    cmd_prefix = [find_bash_on_windows()] if current_os == "Windows" else []
    abs_input_file = os.path.abspath(input_file); abs_output_file = os.path.abspath(output_file)
    bash_input_file = abs_input_file; bash_output_file = abs_output_file
    if current_os == "Windows":
        drive, path_no_drive = os.path.splitdrive(abs_input_file); bash_input_file = ("/" + drive.lower().replace(":", "") + path_no_drive.replace(os.sep, "/")) if drive else abs_input_file.replace(os.sep, "/")
        drive, path_no_drive = os.path.splitdrive(abs_output_file); bash_output_file = ("/" + drive.lower().replace(":", "") + path_no_drive.replace(os.sep, "/")) if drive else abs_output_file.replace(os.sep, "/")
    command = cmd_prefix + [script_path_abs, 'e' if mode == 'encrypt' else 'd', bash_input_file, bash_output_file]
    password_input_str = f"{password}\n" + (f"{password}\n" if mode == 'encrypt' else "")
    try:
        startupinfo = None; creation_flags = 0
        if current_os == "Windows": startupinfo = subprocess.STARTUPINFO(); startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW; startupinfo.wShowWindow = subprocess.SW_HIDE; creation_flags = subprocess.CREATE_NO_WINDOW
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, startupinfo=startupinfo, cwd=os.path.dirname(script_path_abs), creationflags=creation_flags)
        stdout_data, stderr_data = process.communicate(password_input_str, timeout=60)
        if process.returncode == 0: return True, f"File {mode}ed.", stdout_data.strip()
        else:
            err = f"Script err(code {process.returncode}).\nCmd: {' '.join(command)}\nIn: {bash_input_file}\nOut: {bash_output_file}\n";
            if stdout_data: err += f"STDOUT:{stdout_data.strip()}\n"
            if stderr_data: err += f"STDERR:{stderr_data.strip()}"
            return False, err.strip(), stderr_data.strip()
    except subprocess.TimeoutExpired: return False, "Script timeout.", ""
    except FileNotFoundError as e: return False, f"Exec failed: {e}. Bash/script path? Cmd: {' '.join(command)}", ""
    except Exception as e: return False, f"Script exec error: {e}. Cmd: {' '.join(command)}", ""

# --- SFTP CLI Helper Functions ---
def _build_sftp_base_command():
    cmd = []
    sftp_options = ["-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null", "-P", str(SFTP_PORT)]
    if SSH_KEY_PATH:
        sftp_options.extend(["-i", os.path.expanduser(SSH_KEY_PATH)])

    # Try key-based first. If USE_SSHPASS_FALLBACK, then try sshpass.
    # This logic is tricky because sftp client itself doesn't take password directly.
    # For simplicity in this example, if USE_SSHPASS_FALLBACK is true, we assume sshpass is the primary method if keys aren't working seamlessly.
    # A better approach would be to try key-auth, check failure, then try sshpass.
    if USE_SSHPASS_FALLBACK and SFTP_PASS_FOR_FALLBACK:
        if not shutil.which("sshpass"):
            print("WARNING: 'sshpass' is not installed. Password fallback for SFTP will not work.")
            # Fallthrough to key-based attempt without sshpass
            cmd = ["sftp"] + sftp_options
        else:
            cmd = ["sshpass", "-p", SFTP_PASS_FOR_FALLBACK, "sftp"] + sftp_options
    else: # Only key-based
        cmd = ["sftp"] + sftp_options
    return cmd

def sftp_execute_commands(commands_str_list, app_instance_for_msgbox=None):
    """Executes a list of SFTP commands using a batch file approach."""
    sftp_base_cmd = _build_sftp_base_command()
    if not shutil.which(sftp_base_cmd[0]): # Check if sftp or sshpass is found
        msg = f"'{sftp_base_cmd[0]}' command not found. Please ensure it's installed and in your PATH."
        print(f"ERROR: {msg}")
        if app_instance_for_msgbox: messagebox.showerror("SFTP Error", msg, parent=app_instance_for_msgbox)
        return False, f"{sftp_base_cmd[0]} not found"

    target = f"{SFTP_USER}@{SFTP_HOST}"
    
    # Create a temporary batch file
    batch_content = "\n".join(commands_str_list) + "\nquit\n" # Ensure quit
    temp_batch_file = None
    try:
        # Using a named temporary file can be tricky with permissions and subprocesses on some OS.
        # Simpler: create a file in our local temp dir.
        temp_dir = os.path.join(LOCAL_TEMP_DIR_BASE, "sftp_batch")
        os.makedirs(temp_dir, exist_ok=True)
        
        # Generate a unique filename for the batch file
        timestamp = int(time.time() * 1000) # milliseconds for more uniqueness
        batch_filename = f"sftp_batch_{timestamp}.txt"
        temp_batch_file_path = os.path.join(temp_dir, batch_filename)

        with open(temp_batch_file_path, "w") as bf:
            bf.write(batch_content)
        
        print(f"DEBUG: SFTP Batch content for {target}:\n{batch_content}") # For debugging
        print(f"DEBUG: SFTP command: {sftp_base_cmd + ['-b', temp_batch_file_path, target]}")

        process = subprocess.run(
            sftp_base_cmd + ["-b", temp_batch_file_path, target],
            capture_output=True, text=True, timeout=60
        )
 
        
        print(f"DEBUG: SFTP stdout:\n{process.stdout}") # For debugging
        print(f"DEBUG: SFTP stderr:\n{process.stderr}") # For debugging

        if process.returncode == 0:
            # Some "errors" from sftp might go to stdout (e.g., "Couldn't stat remote file: No such file or directory")
            # and still return 0 if other commands in batch succeed. This is a pain.
            # A more robust check would involve looking for specific error strings in stderr/stdout.
            # For now, we'll assume returncode 0 is mostly okay for batch operations like mkdir, put, rm.
            # "File not found" on an `ls` or `stat` might be a soft error we handle.
            if "Authentication failed" in process.stderr or "Permission denied" in process.stderr:
                 return False, f"SFTP Authentication/Permission Error:\n{process.stderr}"
            return True, process.stdout
        else:
            # Concatenate stdout and stderr for error message, as sftp can be inconsistent.
            error_output = f"SFTP Error (code {process.returncode}):\n"
            if process.stdout: error_output += f"STDOUT: {process.stdout.strip()}\n"
            if process.stderr: error_output += f"STDERR: {process.stderr.strip()}"
            return False, error_output.strip()
    except subprocess.TimeoutExpired:
        return False, "SFTP command timed out."
    except FileNotFoundError: # For sftp or sshpass itself
        return False, f"SFTP command '{sftp_base_cmd[0]}' not found. Is it installed and in PATH?"
    except Exception as e:
        return False, f"SFTP execution failed: {e}"
    finally:
        if temp_batch_file_path and os.path.exists(temp_batch_file_path):
            try: os.remove(temp_batch_file_path)
            except OSError: pass


def sftp_list_directory_detailed(remote_path, app_instance_for_msgbox=None):
    """Lists directory contents. Returns list of (name, size, mtime_timestamp, is_dir_flag_ish) tuples."""
    # sftp's `ls -ln` gives numeric UID/GID, `ls -l` gives names.
    # `ls -1` just gives names.
    # We need details, so `ls -ln remote_path` is a good bet.
    # Example output line: -rw-r--r--    1 1000   1000     12345 Dec 18 15:30 filename.enc
    # Or for a directory:   drwxr-xr-x    2 1000   1000      4096 Dec 17 10:00 dirname
    
    # Using a simple `ls` and then inferring might be more reliable than complex parsing.
    # For this, we'll list and then for items we care about (enc files, keyinfo),
    # we can try to `stat` them individually if needed, or just parse `ls -ln`.
    
    commands = [f"ls -ln {remote_path}"] # -n for numeric uid/gid, less parsing hassle
    success, output = sftp_execute_commands(commands, app_instance_for_msgbox)
    
    files = []
    if success:
        print(f"DEBUG: sftp_list_directory_detailed raw output for {remote_path}:\n{output}")
        lines = output.strip().split('\n')
        for line in lines:
            line = line.strip()
            if not line or "Fetching" in line or "Connecting to" in line or "sftp>" in line: # Skip noise
                continue

            # Regex for a typical `ls -l` or `ls -ln` line. This is fragile!
            # Groups: 1:perms, 2:links, 3:owner, 4:group, 5:size, 6:month, 7:day, 8:time/year, 9:filename
            match = re.match(r"^([dl\-][rwx\-]{9})\s+\d+\s+[\w\-]+\s+[\w\-]+\s+(\d+)\s+(\w{3})\s+(\d{1,2})\s+((?:\d{1,2}:\d{2})|(?:\d{4}))\s+(.+)$", line)
            if match:
                perms, size_str, month_str, day_str, time_or_year_str, name = \
                    match.group(1), match.group(5), match.group(6), match.group(7), match.group(8), match.group(9)
                
                if name == "." or name == "..": continue

                is_dir = perms.startswith('d')
                size = int(size_str)
                
                # Attempt to parse date - this is highly problematic with `ls` output
                # OpenSSH sftp `ls` date format can be "Mmm dd HH:MM" or "Mmm dd YYYY"
                # This simple parser assumes current year if only time is given.
                try:
                    dt_obj = None
                    current_year = datetime.now().year
                    if ":" in time_or_year_str: # "HH:MM" format
                        dt_str = f"{month_str} {day_str} {current_year} {time_or_year_str}"
                        dt_obj = datetime.strptime(dt_str, "%b %d %Y %H:%M")
                    else: # "YYYY" format
                        dt_str = f"{month_str} {day_str} {time_or_year_str}"
                        dt_obj = datetime.strptime(dt_str, "%b %d %Y")
                    mtime_timestamp = int(dt_obj.timestamp())
                except ValueError:
                    mtime_timestamp = 0 # Fallback if date parsing fails

                files.append({'name': name, 'size': size, 'mtime': mtime_timestamp, 'is_dir': is_dir, 'attrs': line}) # Store raw line in attrs
            # else:
                # print(f"DEBUG: No match for ls line: '{line}'") # For debugging parsing
        return files
    else:
        # If `ls` fails (e.g., dir not found), output might contain the error.
        # We return an empty list, the error message was in `output` and handled by caller.
        print(f"SFTP list directory failed for {remote_path}. Error: {output}")
        return []


def sftp_mkdir_p_batch(remote_path, app_instance_for_msgbox=None):
    """Creates a directory and its parents if they don't exist using SFTP batch."""
    if not remote_path or remote_path == "/": return True, "Path is root or empty"
    
    parts = remote_path.strip('/').split('/')
    current_path_parts = []
    commands = []
    # We can't reliably check if dir exists and then create in one batch transaction with simple sftp CLI.
    # So, we just try to make them. `mkdir` will fail if it exists, but that's usually fine in a batch.
    # Or, `mkdir -p` isn't a standard sftp command.
    # A common workaround is to `cd` and `mkdir` or just `mkdir` full paths.
    # Let's try full path mkdirs for simplicity, sftp often ignores errors on existing dirs.
    
    # Build path incrementally and add mkdir for each part
    # Example: /a/b/c -> mkdir /a; mkdir /a/b; mkdir /a/b/c
    # This is not truly mkdir -p but often works if sftp server is lenient.
    # More robust: check existence of SFTP_REMOTE_APP_BASE_DIR, then cd into it, then create user dirs.
    # However, `cd` state is per-command in batch usually.
    
    # Let's try a different approach: iterate and mkdir each segment if not root
    # This is still not a true `mkdir -p` but a sequence of `mkdir` commands.
    # SFTP `mkdir` command will typically fail if the directory already exists.
    # This is problematic for `mkdir -p` simulation.
    # `paramiko` handled this much better.
    
    # Simplest for CLI: just try to make the final directory.
    # If it fails, it's an issue. If parent dirs are the problem, this won't solve it.
    # For the app's structure, we usually create:
    # SFTP_REMOTE_APP_BASE_DIR (once)
    # SFTP_REMOTE_APP_BASE_DIR/username (once per user)
    # SFTP_REMOTE_APP_BASE_DIR/username/_my_files (once per user)
    # SFTP_REMOTE_APP_BASE_DIR/username/_shared_with_me (once per user)

    # For this function, let's assume we just want to make ONE directory.
    # The caller needs to ensure parent directories are created.
    
    commands.append(f"mkdir \"{remote_path}\"") # Quote path
    success, output = sftp_execute_commands(commands, app_instance_for_msgbox)
    
    # `mkdir` on sftp might return error if dir exists. We can treat this as success for `mkdir_p`.
    if success:
        return True, output
    elif "File exists" in output or "already exists" in output: # Check for common "exists" messages
        return True, "Directory already exists (considered success for mkdir -p)"
    # Specific check for "Failure" or "Couldn't create directory" might be needed if sftp server is strict
    elif "Couldn't create directory" in output and "File exists" not in output: # Generic failure
        return False, f"mkdir failed for {remote_path}: {output}"
    return success, output # Return original success/output if not specifically "File exists"

def sftp_check_and_create_user_dirs(username, app_instance):
    """Checks and creates the base SFTP directories for a user."""
    base_app_dir_cmd = [f"mkdir \"{SFTP_REMOTE_APP_BASE_DIR}\""] # Try to make base app dir
    sftp_execute_commands(base_app_dir_cmd, app_instance) # Ignore error if it exists

    user_base = f"{SFTP_REMOTE_APP_BASE_DIR}/{username}"
    my_files = f"{user_base}/{SFTP_MY_FILES_DIR_NAME}"
    shared_with_me = f"{user_base}/{SFTP_SHARED_WITH_ME_DIR_NAME}"
    
    paths_to_create = [user_base, my_files, shared_with_me]
    all_created = True
    errors = []

    for path in paths_to_create:
        success, msg = sftp_mkdir_p_batch(path, app_instance) # Using our simplified mkdir
        if not success:
            # It's possible the directory already exists, which sftp_mkdir_p_batch tries to handle.
            # If it's a real failure, then we have a problem.
            if not ("Directory already exists" in msg or "File exists" in msg): # If not an "already exists" success
                all_created = False
                errors.append(f"Failed to ensure SFTP dir {path}: {msg}")
                print(f"SFTP Error: Failed to create directory {path}: {msg}")

    if not all_created:
        messagebox.showerror("SFTP Setup Error", "Failed to create some user directories on SFTP server:\n" + "\n".join(errors), parent=app_instance)
        return False
    
    # Final check: try to list the user's base directory to confirm connectivity & basic setup
    # This is a pseudo connection test.
    test_list_commands = [f"ls \"{user_base}\""]
    conn_success, conn_out = sftp_execute_commands(test_list_commands, app_instance)
    if not conn_success:
        if "Authentication failed" in conn_out or "Permission denied" in conn_out:
             msg = f"SFTP Authentication Failed for {SFTP_USER}@{SFTP_HOST}."
        else:
             msg = f"SFTP connection test failed for user {username}.\nError: {conn_out}"
        print(f"ERROR: {msg}")
        messagebox.showerror("SFTP Connection Error", msg, parent=app_instance)
        return False
        
    print(f"SFTP directories for user '{username}' checked/created.")
    return True

# --- User Registration (Local DB + SFTP Directory Setup) ---
def register_user(username, password, app_instance):
    if not username or not password: return False, "Username/password cannot be empty."
    hashed_pw_str = hash_password_insecure(password)

    # Create SFTP directories for the user
    if not sftp_check_and_create_user_dirs(username, app_instance):
        return False, "Failed to create SFTP user directories. Check SFTP connection and permissions."

    # Register user in local SQLite DB
    conn_auth = sqlite3.connect(DB_NAME_AUTH)
    cursor = conn_auth.cursor()
    try:
        cursor.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                       (username, hashed_pw_str))
        conn_auth.commit()
        return True, "Registration successful! User SFTP directories checked/created."
    except sqlite3.IntegrityError: return False, "Username already taken (local DB)."
    except Exception as e_db: print(f"SQLite Error in register_user: {e_db}"); return False, f"DB error: {e_db}"
    finally: conn_auth.close()


# --- Main Application Class ---
class SecureShareApp(tk.Tk):
    COLOR_BACKGROUND = "#0D1B2A"; COLOR_BACKGROUND_LIGHTER = "#1B263B"; COLOR_FOREGROUND = "#E0E1DD"
    # ... (All other color and font constants remain the same) ...
    COLOR_ACCENT = "#56CFE1"; COLOR_ACCENT_DARKER = "#48B5C4"; COLOR_ENTRY_BG = "#2A3947"
    COLOR_ENTRY_FG = COLOR_ACCENT; COLOR_BUTTON_BG = "#4A5B6F"; COLOR_BUTTON_FG = COLOR_FOREGROUND
    COLOR_BUTTON_ACTIVE_BG = "#6D839D"; COLOR_PRIMARY_ACTION_BG = COLOR_ACCENT
    COLOR_PRIMARY_ACTION_FG = "#070A0E"; COLOR_PRIMARY_ACTION_HOVER_BG = COLOR_ACCENT_DARKER
    COLOR_DISABLED_FG = "#778DA9"; COLOR_BORDER = "#415A77"
    TAG_COLORS = {"normal": COLOR_FOREGROUND, "error": "#FF6B6B", "success": "#70E094", "info": COLOR_ACCENT, "warning": "#FFB4A2"}
    FONT_PRIMARY = ("Consolas", 12); FONT_HEADER = ("Consolas", 24, "bold"); FONT_SUB_HEADER = ("Consolas", 16, "bold")
    FONT_BUTTON = ("Consolas", 12, "bold"); FONT_SMALL = ("Consolas", 10)

    def __init__(self):
        super().__init__()
        self.title("SecureShare Client (CLI SFTP Mode)")
        self.geometry("600x450")
        self.configure(bg=self.COLOR_BACKGROUND); self.resizable(False, False)
        self.poll_job = None; self.current_user_id = None; self.current_user_username = None
        self.sftp_connected_for_session = False # Flag for current session

        self._setup_styles()

        self.container = tk.Frame(self, bg=self.COLOR_BACKGROUND)
        self.container.pack(side="top", fill="both", expand=True)
        self.container.grid_rowconfigure(0, weight=1); self.container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        self._create_auth_view("Login")
        self._create_auth_view("Register")
        self._create_main_app_view()

        self.show_frame("LoginView")
        self.center_window()
        self.POLL_INTERVAL = 75000 # Slightly longer for CLI SFTP
        os.makedirs(LOCAL_TEMP_DIR_BASE, exist_ok=True)
        os.makedirs(os.path.join(LOCAL_TEMP_DIR_BASE, "sftp_batch"), exist_ok=True) # For batch files
        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _on_closing(self):
        # No explicit SFTP client to close like with paramiko
        self.destroy()

    def _setup_styles(self):
        self.style = ttk.Style(self)
        self.style.theme_use('clam')
        # ... (style configurations remain the same as your original)
        self.style.configure("TButton", background=self.COLOR_BUTTON_BG, foreground=self.COLOR_BUTTON_FG, font=self.FONT_BUTTON, relief="flat", padding=(10,6), borderwidth=1, bordercolor=self.COLOR_BORDER, focuscolor=self.COLOR_ACCENT_DARKER)
        self.style.map("TButton", background=[('active',self.COLOR_BUTTON_ACTIVE_BG),('pressed',self.COLOR_ACCENT_DARKER)], bordercolor=[('active',self.COLOR_ACCENT),('focus',self.COLOR_ACCENT)])
        self.style.configure("Treeview", background=self.COLOR_ENTRY_BG, foreground=self.COLOR_FOREGROUND, fieldbackground=self.COLOR_ENTRY_BG, font=self.FONT_PRIMARY, rowheight=28)
        self.style.map("Treeview", background=[('selected',self.COLOR_ACCENT_DARKER)], foreground=[('selected',self.COLOR_PRIMARY_ACTION_FG)])
        self.style.configure("Treeview.Heading", background=self.COLOR_BUTTON_BG, foreground=self.COLOR_FOREGROUND, font=self.FONT_BUTTON, relief="flat", padding=5)
        self.style.map("Treeview.Heading", background=[('active',self.COLOR_BUTTON_ACTIVE_BG)])
        self.style.configure("Vertical.TScrollbar", gripcount=0, background=self.COLOR_BUTTON_BG, darkcolor=self.COLOR_BACKGROUND_LIGHTER, lightcolor=self.COLOR_BACKGROUND_LIGHTER, troughcolor=self.COLOR_BACKGROUND, bordercolor=self.COLOR_BORDER, arrowcolor=self.COLOR_ACCENT, relief='flat')
        self.style.map("Vertical.TScrollbar", background=[('active',self.COLOR_BUTTON_ACTIVE_BG)], arrowcolor=[('pressed',self.COLOR_ACCENT_DARKER)])
        self.style.configure('Link.TLabel', foreground=self.COLOR_ACCENT, font=(self.FONT_PRIMARY[0], self.FONT_PRIMARY[1], 'underline'))

    def center_window(self,width=None,height=None):
        self.update_idletasks();w=width if width else self.winfo_width();h=height if height else self.winfo_height();sw,sh=self.winfo_screenwidth(),self.winfo_screenheight();x,y=max(0,(sw//2)-(w//2)),max(0,(sh//2)-(h//2));self.geometry(f'{w}x{h}+{x}+{y}')

    def _check_sftp_session_connectivity(self):
        if not self.current_user_username: return False
        # Use sftp_check_and_create_user_dirs as a connectivity test as well.
        # It tries to list the user's base directory.
        if sftp_check_and_create_user_dirs(self.current_user_username, self):
            self.sftp_connected_for_session = True
            self.status_bar_label.config(text=f"Status: SFTP Connection OK for {self.current_user_username}")
            return True
        else:
            self.sftp_connected_for_session = False
            # Error message is shown by sftp_check_and_create_user_dirs
            self.status_bar_label.config(text="Status: SFTP Connection Failed.")
            return False

    def start_polling_sftp_files(self):
        main_app_frame = self.frames.get("MainAppView")
        if self.current_user_username and main_app_frame and main_app_frame.winfo_viewable():
            if self.sftp_connected_for_session or self._check_sftp_session_connectivity():
                 main_app_frame.load_user_files_from_sftp()
            else:
                self.stop_polling_sftp_files()
                # Potentially force logout or show persistent error if connection is vital
                if self.current_user_username: # If still logged in locally but SFTP dead
                    messagebox.showerror("SFTP Disconnected", "Lost connection to SFTP server. Please log out and try again.", parent=self)
                    # self._handle_logout() # Optional: force logout
                return

            if hasattr(self,'poll_job') and self.poll_job is not None: self.after_cancel(self.poll_job)
            self.poll_job = self.after(self.POLL_INTERVAL, self.start_polling_sftp_files)

    def stop_polling_sftp_files(self):
        if hasattr(self,'poll_job') and self.poll_job is not None:
            try: self.after_cancel(self.poll_job)
            except tk.TclError: pass
            finally: self.poll_job = None
        self.sftp_connected_for_session = False # Reset session connection status

    def show_frame(self,page_name_key):
        frame=self.frames.get(page_name_key)
        if frame:
            frame.tkraise()
            if page_name_key=="MainAppView":
                self.geometry("1100x750");self.resizable(True,True);self.center_window(1100,750)
                if self._check_sftp_session_connectivity(): # Check/establish connection
                    if hasattr(frame,'load_user_files_from_sftp'): frame.load_user_files_from_sftp()
                    self.start_polling_sftp_files()
                else:
                    messagebox.showerror("SFTP Error", "Cannot switch to main view: SFTP connection failed. Please check settings and network.", parent=self)
                    self.show_frame("LoginView") # Revert to login
                    return
            else: # Auth views
                self.stop_polling_sftp_files()
                self.geometry("600x450");self.resizable(False,False);self.center_window(600,450)
                if hasattr(frame, 'auth_vars') and 'password' in frame.auth_vars: frame.auth_vars['password'].set("") # Clear fields
                # ... (rest of auth view setup for show_frame)
                if hasattr(frame, 'auth_vars') and 'confirm_password' in frame.auth_vars: frame.auth_vars['confirm_password'].set("")
                if hasattr(frame, 'auth_vars') and 'error_label' in frame.auth_vars: frame.auth_vars['error_label'].config(text="")


    def _create_input_field(self,parent,text,show_char=None,is_confirm=False):
        # ... (same as before)
        f=tk.Frame(parent,bg=self.COLOR_BACKGROUND);tk.Label(f,text=text,bg=self.COLOR_BACKGROUND,fg=self.COLOR_FOREGROUND,font=self.FONT_PRIMARY,width=18,anchor='w').pack(side="left",padx=(0,10));v=tk.StringVar();e=tk.Entry(f,textvariable=v,bg=self.COLOR_ENTRY_BG,fg=self.COLOR_ENTRY_FG,insertbackground=self.COLOR_ACCENT,font=self.FONT_PRIMARY,relief='flat',show=show_char,borderwidth=2,highlightthickness=0);e.pack(side="left",fill="x",expand=True);return f,v,e

    def _create_auth_view(self, mode="Login"):
        frame_key = f"{mode}View"
        frame = tk.Frame(self.container, bg=self.COLOR_BACKGROUND)
        # ... (Auth view UI elements creation, same as before, but update title) ...
        self.frames[frame_key] = frame
        frame.grid(row=0, column=0, sticky="nsew")
        content_frame = tk.Frame(frame, bg=self.COLOR_BACKGROUND)
        content_frame.place(relx=0.5, rely=0.5, anchor="center")
        header_text = "SecureShare Login (CLI SFTP)" if mode == "Login" else "Create Account (CLI SFTP)"
        header = tk.Label(content_frame, text=header_text, font=self.FONT_HEADER, bg=self.COLOR_BACKGROUND, fg=self.COLOR_ACCENT)
        header.pack(pady=(0, 30))
        frame.auth_vars = {}
        username_frame, username_var, _ = self._create_input_field(content_frame, "Username:")
        username_frame.pack(pady=8, fill="x", padx=20); frame.auth_vars["username"] = username_var
        password_frame, password_var, _ = self._create_input_field(content_frame, "Password:", show_char='●')
        password_frame.pack(pady=8, fill="x", padx=20); frame.auth_vars["password"] = password_var
        if mode == "Register":
            confirm_password_frame, confirm_password_var, _ = self._create_input_field(content_frame, "Confirm Password:", show_char='●')
            confirm_password_frame.pack(pady=8, fill="x", padx=20); frame.auth_vars["confirm_password"] = confirm_password_var
        error_label = tk.Label(content_frame, text="", font=self.FONT_SMALL,bg=self.COLOR_BACKGROUND, fg=self.TAG_COLORS["error"], wraplength=350)
        error_label.pack(pady=(5, 10)); frame.auth_vars["error_label"] = error_label
        button_base_config = {"font": self.FONT_BUTTON, "relief": 'flat', "borderwidth": 1, "width": 20, "pady": 8}
        primary_button_config = {**button_base_config, "bg": self.COLOR_PRIMARY_ACTION_BG, "fg": self.COLOR_PRIMARY_ACTION_FG, "activebackground": self.COLOR_PRIMARY_ACTION_HOVER_BG, "activeforeground": self.COLOR_PRIMARY_ACTION_FG}
        secondary_button_config = {**button_base_config, "bg": self.COLOR_BUTTON_BG, "fg": self.COLOR_BUTTON_FG, "activebackground": self.COLOR_BUTTON_ACTIVE_BG}
        if mode == "Login":
            tk.Button(content_frame, text="Login", command=self._handle_login, **primary_button_config).pack(pady=(10, 5))
            tk.Button(content_frame, text="Create Account", command=lambda: self.show_frame("RegisterView"), **secondary_button_config).pack(pady=5)
        else: # Register
            tk.Button(content_frame, text="Register", command=self._handle_register, **primary_button_config).pack(pady=(10, 5))
            tk.Button(content_frame, text="Back to Login", command=lambda: self.show_frame("LoginView"), **secondary_button_config).pack(pady=5)

    def _handle_login(self):
        login_frame = self.frames["LoginView"]
        username = login_frame.auth_vars["username"].get()
        password = login_frame.auth_vars["password"].get()
        error_label = login_frame.auth_vars["error_label"]
        success, message, user_id, fetched_username = login_user(username, password) # Local DB check
        if success:
            self.current_user_id = user_id
            self.current_user_username = fetched_username
            # Attempt to "connect" to SFTP (really, check dirs and basic comms)
            if self._check_sftp_session_connectivity():
                error_label.config(text=message + " SFTP OK.", fg=self.TAG_COLORS["success"])
                login_frame.auth_vars["username"].set("")
                self.after(1000, lambda: self.show_frame("MainAppView"))
            else:
                # SFTP connection failed after successful local auth
                self.current_user_id = None # Rollback login state
                self.current_user_username = None
                self.sftp_connected_for_session = False
                # Error message should have been shown by _check_sftp_session_connectivity
                error_label.config(text="Local login OK, but SFTP connection failed.", fg=self.TAG_COLORS["error"])
        else:
            error_label.config(text=message, fg=self.TAG_COLORS["error"])
        login_frame.auth_vars["password"].set("")

    def _handle_register(self):
        register_frame = self.frames["RegisterView"]
        username = register_frame.auth_vars["username"].get()
        password = register_frame.auth_vars["password"].get()
        # ... (rest of validation from original _handle_register)
        confirm_password = register_frame.auth_vars["confirm_password"].get()
        error_label = register_frame.auth_vars["error_label"]
        if not username.strip() or not password: error_label.config(text="Username and password cannot be empty.", fg=self.TAG_COLORS["error"]); return
        if password != confirm_password: error_label.config(text="Passwords do not match.", fg=self.TAG_COLORS["error"]); return
        if len(password) < 8: error_label.config(text="Password must be at least 8 characters.", fg=self.TAG_COLORS["error"]); return

        success, message = register_user(username, password, self) # Pass app instance for msgbox
        
        if success:
            error_label.config(text=message, fg=self.TAG_COLORS["success"])
            register_frame.auth_vars["username"].set("")
            register_frame.auth_vars["password"].set("")
            register_frame.auth_vars["confirm_password"].set("")
            self.after(1500, lambda: self.show_frame("LoginView"))
        else:
            error_label.config(text=message, fg=self.TAG_COLORS["error"])
            register_frame.auth_vars["password"].set("")
            register_frame.auth_vars["confirm_password"].set("")

    def _create_main_app_view(self):
        frame = tk.Frame(self.container,bg=self.COLOR_BACKGROUND)
        self.frames["MainAppView"]=frame
        # ... (UI structure same as original, button commands will change)
        frame.grid(row=0,column=0,sticky="nsew"); frame.grid_columnconfigure(0,weight=1); frame.grid_rowconfigure(2,weight=1)
        header_area = tk.Frame(frame,bg=self.COLOR_BACKGROUND_LIGHTER,padx=10,pady=10)
        header_area.grid(row=0,column=0,columnspan=2,sticky="ew"); header_area.grid_columnconfigure(0,weight=1)
        tk.Label(header_area,text="SecureShare (CLI SFTP)",font=self.FONT_HEADER,bg=self.COLOR_BACKGROUND_LIGHTER,fg=self.COLOR_ACCENT).grid(row=0,column=0,sticky="w")
        self.current_user_label=tk.Label(header_area,text="User: N/A",font=self.FONT_PRIMARY,bg=self.COLOR_BACKGROUND_LIGHTER,fg=self.COLOR_FOREGROUND)
        self.current_user_label.grid(row=0,column=1,sticky="e",padx=(0,20))
        ttk.Button(header_area,text="Logout",style="TButton",command=self._handle_logout,width=8).grid(row=0,column=2,sticky="e",padx=(0,10))
        
        toolbar_frame = tk.Frame(frame,bg=self.COLOR_BACKGROUND,pady=10)
        toolbar_frame.grid(row=1,column=0,columnspan=2,sticky="ew",padx=20)
        ttk.Button(toolbar_frame,text="Upload to SFTP",style="TButton",command=self._upload_file_sftp).pack(side="left",padx=5)
        ttk.Button(toolbar_frame,text="Download from SFTP",style="TButton",command=self._download_file_sftp).pack(side="left",padx=5)
        ttk.Button(toolbar_frame,text="Delete from SFTP",style="TButton",command=self._delete_file_sftp).pack(side="left",padx=5)
        ttk.Button(toolbar_frame,text="Share via SFTP",style="TButton",command=self._share_file_sftp_user).pack(side="left",padx=5)
        ttk.Button(toolbar_frame,text="Refresh List",style="TButton",command=lambda:self.frames["MainAppView"].load_user_files_from_sftp()).pack(side="left",padx=5)
        
        file_list_frame = tk.Frame(frame,bg=self.COLOR_BACKGROUND)
        file_list_frame.grid(row=2,column=0,columnspan=2,sticky="nsew",padx=20,pady=(0,10)); file_list_frame.grid_rowconfigure(0,weight=1); file_list_frame.grid_columnconfigure(0,weight=1)
        cols=("filename","size_approx","modified_remote","owner_sharer","status_type", "remote_path_hidden") # remote_path_hidden is key
        self.file_tree=ttk.Treeview(file_list_frame,columns=cols,show="headings",style="Treeview",selectmode="browse", displaycolumns=("filename","size_approx","modified_remote","owner_sharer","status_type"))
        # ... (Treeview column setup same as original) ...
        self.file_tree.heading("filename",text="Filename (Original)"); self.file_tree.column("filename",width=300,stretch=tk.YES)
        self.file_tree.heading("size_approx",text="Size",anchor="e"); self.file_tree.column("size_approx",width=100,stretch=tk.NO,anchor="e")
        self.file_tree.heading("modified_remote",text="Date (Remote Mod)",anchor="center"); self.file_tree.column("modified_remote",width=180,stretch=tk.NO,anchor="center")
        self.file_tree.heading("owner_sharer",text="Owner / Shared By",anchor="w"); self.file_tree.column("owner_sharer",width=200,stretch=tk.NO,anchor="w")
        self.file_tree.heading("status_type",text="Status",anchor="center"); self.file_tree.column("status_type",width=100,stretch=tk.NO,anchor="center")
        self.file_tree.grid(row=0,column=0,sticky="nsew");sb=ttk.Scrollbar(file_list_frame,orient="vertical",command=self.file_tree.yview,style="Vertical.TScrollbar");self.file_tree.configure(yscrollcommand=sb.set);sb.grid(row=0,column=1,sticky="ns")
        
        self.status_bar_label=tk.Label(frame,text="Status: Ready",font=self.FONT_SMALL,bg=self.COLOR_BORDER,fg=self.COLOR_FOREGROUND,anchor="w",padx=10)
        self.status_bar_label.grid(row=3,column=0,columnspan=2,sticky="ew",pady=(5,0))
        frame.load_user_files_from_sftp = self._load_user_files_from_sftp # Assign method

    def _get_user_sftp_paths(self, username=None): # Remote paths
        user = username if username else self.current_user_username
        if not user: return None, None, None
        user_base = f"{SFTP_REMOTE_APP_BASE_DIR}/{user}"
        my_files = f"{user_base}/{SFTP_MY_FILES_DIR_NAME}"
        shared_with_me = f"{user_base}/{SFTP_SHARED_WITH_ME_DIR_NAME}"
        return user_base, my_files, shared_with_me

    def _load_user_files_from_sftp(self):
        if not self.current_user_username or not self.sftp_connected_for_session:
            self.status_bar_label.config(text="Status: Not connected to SFTP for file listing.")
            # Try to reconnect if session flag is false but user is logged in
            if self.current_user_username and not self._check_sftp_session_connectivity():
                messagebox.showwarning("SFTP Error", "SFTP disconnected. Cannot load files.", parent=self)
                return # Do not proceed if still not connected
            elif not self.current_user_username: # Should not happen if logic is correct
                return

        self.current_user_label.config(text=f"User: {self.current_user_username}")
        current_selection_iid = self.file_tree.focus()
        for item in self.file_tree.get_children(): self.file_tree.delete(item)

        _, my_files_sftp_path, shared_sftp_path = self._get_user_sftp_paths()

        # Load Owned Files
        owned_file_infos = sftp_list_directory_detailed(my_files_sftp_path, self)
        for finfo in owned_file_infos:
            if finfo['name'].startswith("enc_") and finfo['name'].endswith(".enc") and not finfo['is_dir']:
                full_remote_path = f"{my_files_sftp_path}/{finfo['name']}" # Ensure path uses /
                parts = finfo['name'].split('_', 2)
                original_name_with_ext = parts[2] if len(parts) > 2 else finfo['name']
                original_name = os.path.splitext(original_name_with_ext)[0]
                self._insert_sftp_file_into_tree(
                    original_name, finfo['size'], datetime.fromtimestamp(finfo['mtime']),
                    full_remote_path, "Owned", self.current_user_username
                )

        # Load Shared Files
        # First, list the sharer directories within the user's _shared_with_me path
        sharer_dirs_infos = sftp_list_directory_detailed(shared_sftp_path, self)
        for sharer_dir_info in sharer_dirs_infos:
            if sharer_dir_info['is_dir']: # This is_dir flag from `ls -l` parsing is crucial
                sharer_username_on_sftp = sharer_dir_info['name']
                full_sharer_dir_sftp_path = f"{shared_sftp_path}/{sharer_username_on_sftp}"
                
                shared_file_infos = sftp_list_directory_detailed(full_sharer_dir_sftp_path, self)
                for sfile_info in shared_file_infos:
                    if sfile_info['name'].startswith("enc_") and sfile_info['name'].endswith(".enc") and not sfile_info['is_dir']:
                        full_remote_shared_path = f"{full_sharer_dir_sftp_path}/{sfile_info['name']}"
                        parts_shared = sfile_info['name'].split('_', 2)
                        original_name_shared_ext = parts_shared[2] if len(parts_shared) > 2 else sfile_info['name']
                        original_name_shared = os.path.splitext(original_name_shared_ext)[0]
                        self._insert_sftp_file_into_tree(
                            original_name_shared, sfile_info['size'], datetime.fromtimestamp(sfile_info['mtime']),
                            full_remote_shared_path, "Shared", sharer_username_on_sftp
                        )
        
        if current_selection_iid and self.file_tree.exists(current_selection_iid):
            self.file_tree.focus(current_selection_iid); self.file_tree.selection_set(current_selection_iid)
        elif self.file_tree.get_children():
            first_item = self.file_tree.get_children()[0]
            self.file_tree.focus(first_item); self.file_tree.selection_set(first_item)
        self.status_bar_label.config(text="Status: File list updated from SFTP.")


    def _insert_sftp_file_into_tree(self, display_filename, size_bytes, mod_time_obj, remote_file_path, file_type, owner_sharer_username):
        # ... (same as before)
        size_str = f"{size_bytes/(1024*1024):.1f} MB" if size_bytes >=1024*1024 else (f"{size_bytes/1024:.1f} KB" if size_bytes >= 1024 else f"{size_bytes} B")
        date_str = mod_time_obj.strftime('%Y-%m-%d %H:%M') if isinstance(mod_time_obj, datetime) else "-"
        item_iid = remote_file_path # Full remote path for unique IID
        try:
            self.file_tree.insert("", "end", iid=item_iid,
                                  values=(display_filename, size_str, date_str, owner_sharer_username, file_type, remote_file_path),
                                  tags=(file_type.lower(),))
        except tk.TclError as e:
             print(f"Error inserting into tree (iid: {item_iid}): {e}. File: {display_filename}")


    def _get_selected_file_info_sftp(self):
        # ... (same as before)
        selected_tree_iid = self.file_tree.focus()
        if not selected_tree_iid:
            messagebox.showwarning("No Selection", "Please select a file.", parent=self)
            return None, None, None, None
        try:
            item_values = self.file_tree.item(selected_tree_iid, "values")
            display_name = item_values[0]; remote_enc_path = item_values[5]
            file_type = item_values[4]; owner_sharer = item_values[3]
            return display_name, remote_enc_path, file_type, owner_sharer
        except (IndexError, ValueError) as e:
            messagebox.showerror("Internal Error", f"Could not parse selected item data: {e}\nIID: {selected_tree_iid}", parent=self)
            return None, None, None, None

    def _prompt_password(self, title="Enter Password", prompt="Password:"):
        return simpledialog.askstring(title, prompt, parent=self, show='●')

    def _upload_file_sftp(self):
        if not self.current_user_username or not self.sftp_connected_for_session:
            messagebox.showerror("SFTP Error", "Not connected to SFTP. Cannot upload.", parent=self); return
        
        local_source_filepath = filedialog.askopenfilename(parent=self,title="Select file to encrypt & upload to SFTP")
        if not local_source_filepath: return

        original_filename_base = os.path.basename(local_source_filepath)
        timestamp = int(time.time())
        sftp_encrypted_filename = f"enc_{timestamp}_{original_filename_base}.enc"

        temp_user_dir = os.path.join(LOCAL_TEMP_DIR_BASE, self.current_user_username, "uploads")
        os.makedirs(temp_user_dir, exist_ok=True)
        local_temp_encrypted_path = os.path.join(temp_user_dir, sftp_encrypted_filename)

        file_enc_password = self._prompt_password(title="File Encryption Password", prompt=f"Enter password to encrypt '{original_filename_base}':")
        if not file_enc_password: self.status_bar_label.config(text="Status: Upload cancelled."); return

        self.status_bar_label.config(text=f"Status: Encrypting {original_filename_base} locally..."); self.update_idletasks()
        enc_success, enc_msg, _ = run_encryption_script('encrypt', local_source_filepath, local_temp_encrypted_path, file_enc_password)

        if not enc_success:
            self.status_bar_label.config(text="Status: Local encryption failed."); messagebox.showerror("Encryption Failed", enc_msg, parent=self)
            if os.path.exists(local_temp_encrypted_path): os.remove(local_temp_encrypted_path)
            return

        _, my_files_sftp_path, _ = self._get_user_sftp_paths()
        remote_target_path = f"{my_files_sftp_path}/{sftp_encrypted_filename}" # Ensure forward slashes

        self.status_bar_label.config(text=f"Status: Uploading '{sftp_encrypted_filename}' to SFTP..."); self.update_idletasks()
        
        # Ensure remote "my_files" dir exists (sftp_mkdir_p_batch might be too simple here)
        # sftp_check_and_create_user_dirs should have handled it, but a specific mkdir for my_files_sftp_path is safer.
        sftp_mkdir_p_batch(my_files_sftp_path, self) # Try to make sure the target dir exists

        upload_commands = [f"put \"{local_temp_encrypted_path}\" \"{remote_target_path}\""]
        success_up, msg_up = sftp_execute_commands(upload_commands, self)

        if success_up:
            self.status_bar_label.config(text=f"Status: '{original_filename_base}' uploaded to SFTP.")
            messagebox.showinfo("Success", "File encrypted and uploaded to SFTP.", parent=self)
            self._load_user_files_from_sftp()
        else:
            self.status_bar_label.config(text=f"Status: SFTP upload failed."); messagebox.showerror("SFTP Upload Error", f"Failed to upload: {msg_up}", parent=self)
        
        if os.path.exists(local_temp_encrypted_path): os.remove(local_temp_encrypted_path)
        # ... (cleanup of temp_user_dir if empty)
        if os.path.exists(temp_user_dir) and not os.listdir(temp_user_dir):
            try: shutil.rmtree(os.path.dirname(temp_user_dir))
            except OSError: pass

    def _download_file_sftp(self):
        if not self.current_user_username or not self.sftp_connected_for_session:
            messagebox.showerror("SFTP Error", "Not connected to SFTP. Cannot download.", parent=self); return
        
        display_filename, remote_enc_path, file_type, owner_sharer_username = self._get_selected_file_info_sftp()
        if not remote_enc_path: return

        temp_user_dir = os.path.join(LOCAL_TEMP_DIR_BASE, self.current_user_username, "downloads")
        os.makedirs(temp_user_dir, exist_ok=True)
        local_temp_encrypted_download_path = os.path.join(temp_user_dir, os.path.basename(remote_enc_path))

        self.status_bar_label.config(text=f"Status: Downloading '{display_filename}' from SFTP..."); self.update_idletasks()
        download_commands = [f"get \"{remote_enc_path}\" \"{local_temp_encrypted_download_path}\""]
        success_dl, msg_dl = sftp_execute_commands(download_commands, self)

        if not success_dl:
            self.status_bar_label.config(text=f"Status: SFTP download failed."); messagebox.showerror("SFTP Download Error", f"Failed to download '{display_filename}': {msg_dl}", parent=self)
            if os.path.exists(local_temp_encrypted_download_path): os.remove(local_temp_encrypted_download_path)
            return

        decryption_password = None
        if file_type == "Owned":
            decryption_password = self._prompt_password(title="Decrypt Owned File", prompt=f"Enter password for '{display_filename}':")
        elif file_type == "Shared":
            remote_keyinfo_path = remote_enc_path + SFTP_KEY_SUFFIX
            local_temp_keyinfo_path = local_temp_encrypted_download_path + SFTP_KEY_SUFFIX # Next to temp enc file
            
            key_dl_commands = [f"get \"{remote_keyinfo_path}\" \"{local_temp_keyinfo_path}\""]
            success_key_dl, msg_key_dl = sftp_execute_commands(key_dl_commands, self)
            if success_key_dl and os.path.exists(local_temp_keyinfo_path):
                try:
                    with open(local_temp_keyinfo_path, 'r') as kf: decryption_password = kf.read().strip()
                    os.remove(local_temp_keyinfo_path)
                except IOError as e_io:
                    messagebox.showerror("Error", f"Could not read temp keyinfo file: {e_io}", parent=self)
            else:
                messagebox.showerror("Error", f"Could not download keyinfo for shared file ({remote_keyinfo_path}):\n{msg_key_dl}", parent=self)

        if not decryption_password:
            self.status_bar_label.config(text="Status: Download cancelled (no password/key).")
            if os.path.exists(local_temp_encrypted_download_path): os.remove(local_temp_encrypted_download_path)
            return

        save_location_decrypted = filedialog.asksaveasfilename(parent=self, title="Save decrypted file as", initialfile=display_filename)
        if not save_location_decrypted:
            self.status_bar_label.config(text="Status: Save cancelled.")
            if os.path.exists(local_temp_encrypted_download_path): os.remove(local_temp_encrypted_download_path)
            return

        self.status_bar_label.config(text=f"Status: Decrypting '{display_filename}' locally..."); self.update_idletasks()
        dec_success, dec_msg, _ = run_encryption_script('decrypt', local_temp_encrypted_download_path, save_location_decrypted, decryption_password)

        if dec_success:
            self.status_bar_label.config(text=f"Status: '{display_filename}' decrypted and saved.")
            messagebox.showinfo("Success", f"File saved to {save_location_decrypted}", parent=self)
        else:
            self.status_bar_label.config(text="Status: Decryption failed."); messagebox.showerror("Decryption Failed", dec_msg, parent=self)
            if os.path.exists(save_location_decrypted) and os.path.getsize(save_location_decrypted) == 0:
                try: os.remove(save_location_decrypted)
                except OSError: pass
        
        if os.path.exists(local_temp_encrypted_download_path): os.remove(local_temp_encrypted_download_path)
        # ... (cleanup of temp_user_dir if empty)
        if os.path.exists(temp_user_dir) and not os.listdir(temp_user_dir):
            try: shutil.rmtree(os.path.dirname(temp_user_dir))
            except OSError: pass

    def _delete_file_sftp(self):
        if not self.current_user_username or not self.sftp_connected_for_session:
            messagebox.showerror("SFTP Error", "Not connected to SFTP. Cannot delete.", parent=self); return
        
        display_filename, remote_enc_path, file_type, _ = self._get_selected_file_info_sftp()
        if not remote_enc_path: return

        confirm_msg = f"Permanently delete '{display_filename}' from SFTP server?"
        if not messagebox.askyesno("Confirm Delete", confirm_msg, parent=self, icon='warning'):
            self.status_bar_label.config(text="Status: Delete cancelled."); return

        self.status_bar_label.config(text=f"Status: Deleting '{display_filename}' from SFTP..."); self.update_idletasks()
        
        delete_commands = [f"rm \"{remote_enc_path}\""]
        if file_type == "Shared":
            remote_keyinfo_path = remote_enc_path + SFTP_KEY_SUFFIX
            delete_commands.append(f"rm \"{remote_keyinfo_path}\"") # Try to remove keyinfo too

        success_del, msg_del = sftp_execute_commands(delete_commands, self)
        
        # `rm` on sftp might "succeed" (return 0) even if one file in batch doesn't exist.
        # We need to check output for "Couldn't remove file" or similar.
        # This is very fragile. For now, assume if overall sftp process is 0, it's mostly okay.
        if success_del:
             # A more robust check would parse msg_del for specific "not found" vs "deleted"
            if "No such file or directory" in msg_del and remote_enc_path in msg_del:
                self.status_bar_label.config(text=f"Status: '{display_filename}' was already gone from SFTP.")
                messagebox.showinfo("Info", "File not found on SFTP (already deleted).", parent=self)
            else:
                self.status_bar_label.config(text=f"Status: '{display_filename}' delete command sent to SFTP.")
                messagebox.showinfo("Success", "File delete command sent to SFTP server.", parent=self)
            self._load_user_files_from_sftp()
        else:
            self.status_bar_label.config(text=f"Status: SFTP delete failed."); messagebox.showerror("SFTP Delete Error", f"Could not delete from SFTP: {msg_del}", parent=self)
            self._load_user_files_from_sftp() # Refresh anyway

    def _share_file_sftp_user(self):
        if not self.current_user_username or not self.sftp_connected_for_session:
            messagebox.showerror("SFTP Error", "Not connected. Cannot share.", parent=self); return
        
        display_filename_owner, remote_owner_enc_path, file_type_owner, _ = self._get_selected_file_info_sftp()
        if not remote_owner_enc_path or file_type_owner != "Owned":
            messagebox.showerror("Error", "Select an 'Owned' file to share.", parent=self); return

        recipient_username = simpledialog.askstring("Share File (SFTP)",f"Enter app username to share '{display_filename_owner}' with:", parent=self)
        if not recipient_username or not recipient_username.strip() or recipient_username == self.current_user_username:
            messagebox.showinfo("Share Info", "Invalid recipient username.", parent=self); return

        # Validate recipient user exists (local DB)
        conn_auth = sqlite3.connect(DB_NAME_AUTH); cur_auth = conn_auth.cursor()
        cur_auth.execute("SELECT id FROM users WHERE username = ?", (recipient_username,))
        if not cur_auth.fetchone():
            messagebox.showwarning("User Not Found", f"App user '{recipient_username}' not found.", parent=self)
            conn_auth.close(); return
        conn_auth.close()

        file_master_password = self._prompt_password(title="Provide File Encryption Password", prompt=f"Enter YOUR password for '{display_filename_owner}':")
        if not file_master_password: messagebox.showinfo("Share Cancelled", "No password provided.", parent=self); return

        self.status_bar_label.config(text=f"Status: Sharing '{display_filename_owner}' with '{recipient_username}'..."); self.update_idletasks()
        
        # 1. Temp local path for owner's file and keyinfo
        temp_user_dir = os.path.join(LOCAL_TEMP_DIR_BASE, self.current_user_username, "sharing_temp")
        os.makedirs(temp_user_dir, exist_ok=True)
        local_temp_enc_for_share = os.path.join(temp_user_dir, os.path.basename(remote_owner_enc_path))
        local_temp_keyinfo_for_share = local_temp_enc_for_share + SFTP_KEY_SUFFIX

        # 2. Download owner's encrypted file to local temp
        dl_own_cmd = [f"get \"{remote_owner_enc_path}\" \"{local_temp_enc_for_share}\""]
        success_dl_own, msg_dl_own = sftp_execute_commands(dl_own_cmd, self)
        if not success_dl_own or not os.path.exists(local_temp_enc_for_share):
            messagebox.showerror("Share Error", f"Failed to download own file for sharing: {msg_dl_own}", parent=self)
            if os.path.exists(local_temp_enc_for_share): os.remove(local_temp_enc_for_share)
            return

        # 3. Prepare recipient's SFTP paths and ensure target dir exists
        _, _, recipient_shared_base_sftp_path = self._get_user_sftp_paths(recipient_username)
        sharer_specific_dir_in_recipient_share = f"{recipient_shared_base_sftp_path}/{self.current_user_username}"
        sftp_mkdir_p_batch(sharer_specific_dir_in_recipient_share, self) # Try to create target share dir

        recipient_copied_enc_file_sftp_path = f"{sharer_specific_dir_in_recipient_share}/{os.path.basename(remote_owner_enc_path)}"
        key_info_sftp_path_for_recipient = recipient_copied_enc_file_sftp_path + SFTP_KEY_SUFFIX

        # 4. Create keyinfo file locally
        try:
            with open(local_temp_keyinfo_for_share, 'w') as f_key_temp: f_key_temp.write(file_master_password)
        except IOError as e_io_key:
            messagebox.showerror("Share Error", f"Failed to create temp keyinfo file: {e_io_key}", parent=self)
            if os.path.exists(local_temp_enc_for_share): os.remove(local_temp_enc_for_share)
            if os.path.exists(local_temp_keyinfo_for_share): os.remove(local_temp_keyinfo_for_share)
            return

        # 5. Upload encrypted file and keyinfo file to recipient's share
        upload_share_cmds = [
            f"put \"{local_temp_enc_for_share}\" \"{recipient_copied_enc_file_sftp_path}\"",
            f"put \"{local_temp_keyinfo_for_share}\" \"{key_info_sftp_path_for_recipient}\""
        ]
        success_up_share, msg_up_share = sftp_execute_commands(upload_share_cmds, self)

        if success_up_share:
            # Crude check if both files likely made it. A better SFTP client would give per-file status.
            # We could try `ls` on both remote files here to confirm.
            self.status_bar_label.config(text=f"Status: '{display_filename_owner}' shared with '{recipient_username}'.")
            messagebox.showinfo("Shared (SFTP)", f"'{display_filename_owner}' shared with '{recipient_username}'.", parent=self)
        else:
            messagebox.showerror("SFTP Share Error", f"Failed to upload shared files: {msg_up_share}", parent=self)
        
        # Cleanup local temp files
        if os.path.exists(local_temp_enc_for_share): os.remove(local_temp_enc_for_share)
        if os.path.exists(local_temp_keyinfo_for_share): os.remove(local_temp_keyinfo_for_share)
        # ... (cleanup of temp_user_dir if empty)
        if os.path.exists(temp_user_dir) and not os.listdir(temp_user_dir):
            try: shutil.rmtree(os.path.dirname(temp_user_dir))
            except OSError: pass

    def _handle_logout(self):
        self.stop_polling_sftp_files() # This also sets sftp_connected_for_session to False
        self.current_user_id = None; self.current_user_username = None
        # ... (rest of logout, clearing fields, showing LoginView)
        login_frame = self.frames.get("LoginView")
        if login_frame and hasattr(login_frame, 'auth_vars'):
            login_frame.auth_vars["username"].set(""); login_frame.auth_vars["password"].set("")
            login_frame.auth_vars["error_label"].config(text="")
        self.show_frame("LoginView")
        if hasattr(self,'status_bar_label'): self.status_bar_label.config(text="Status: Logged out.")

if __name__ == "__main__":
    if platform.system() != "Windows" and os.path.exists(CODE_SH_SCRIPT_PATH):
        if not os.access(CODE_SH_SCRIPT_PATH, os.X_OK):
            try: os.chmod(CODE_SH_SCRIPT_PATH, 0o755); print(f"Made '{CODE_SH_SCRIPT_PATH}' executable.")
            except Exception as e: print(f"Warning: Could not make '{CODE_SH_SCRIPT_PATH}' executable: {e}")
    elif not os.path.exists(CODE_SH_SCRIPT_PATH):
         print(f"CRITICAL ERROR: Encryption script '{CODE_SH_SCRIPT_PATH}' not found.")
         # import sys; sys.exit(f"Error: Missing {CODE_SH_SCRIPT_PATH}")

    init_auth_db()
    app = SecureShareApp()
    app.mainloop()