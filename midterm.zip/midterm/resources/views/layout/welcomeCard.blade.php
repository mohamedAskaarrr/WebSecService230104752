
<div class="container mt-4">

    <div class="card text-center shadow-lg">
        <div class="card-header bg-primary text-white">
            <h2>Welcome, Dr.Mohamed Sobh!</h2>
        </div>
        <div class="card-body">
            <h4 class="text-secondary">Student: <strong>Mohamed Tarek Sayed</strong></h4>
            <h5 class="text-secondary">ID: <strong>230102535</strong></h5>
            <p class="mt-3">Here is a list of my works. Thank you for your time!</p>
        </div>
    </div>
